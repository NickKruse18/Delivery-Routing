
SolvePath = function(Map){
  n = Map$size;  from = Map$from;  to = Map$to;  start = Map$start
  E = GenerateEdges(n,from,to,start);  N = c(start,from,to);  n = length(N)
  m = nrow(E);  c.v = E[,3];  E = E[,-3];  A = matrix(0,2*n,m)
  for(i in 1:n){
    A[i+c(0,n),E[,1]==N[i]] = 1
    A[i+n,E[,2]==N[i]] = -1
  }
  r = c(rep("==",n),rep("==",n));  b = c(rep(1,n),rep(0,n))
  w = T
  while(w){
    w = F
    x = lp(objective.in = c.v, const.mat = A, const.dir = r, const.rhs = b, all.int = T)$solution
    E.x = E[x==1,];  I = (1:m)[x==1]
    checked = rep(0,nrow(E.x));  i = 1;  path = start;  Paths = matrix(0,length(E.x)%/%2,m);  p = 0;  P = numeric(nrow(Paths))
    while(sum(checked)<nrow(E.x)){
      if(checked[i] == 1){
        w = T;  p = p + 1;  path = path[-1]
        Paths[p,I[path]] = 1;  P[p] = length(path)
        i = match(0,checked);  path = i;  checked[i] = 1
      }
      else{ checked[i] = 1 }
      i = match(E.x[i,2],E.x[,1]);  path = c(path,i)
    }
    if(w){
      A = rbind(A,Paths[1:p,])
      b = c(b,P[1:p]-0.5);  r = c(r,rep("<",p))
    }
    else{
      path = start;  path.i = c()
      for(i in 2:nrow(E.x)){
        path.i = c(path.i,match(path[i-1],E.x[,1]));  path = c(path,E.x[path.i[i-1],2]);
      }
      from.i = match(from,path);  to.i = match(to,path)
      paths = to.i<from.i
      print(path)
      if(sum(paths)>0){
        w = T
        for(i in 1:length(paths)){
          if(!paths[i]){ next }
          d = matrix(0,3,ncol(A));  d[1,I[path.i[1:to.i[i]]]] = 1
          d[2,I[path.i[to.i[i]:from.i[i]]]] = 1;  d[3,I[path.i[from.i[i]:length(path)]]] = 1
          A = rbind(A,d);  b = c(b,c(sum(d[1,]),sum(d[2,]),sum(d[3,]))-0.5);  r = c(r,rep("<",3))
        }
      }
    }
  }
  Map$path = E.x[match(path,E.x[,1]),]
  PlotPath(Map)
  return(Map)
}

GenerateEdges = function(n,from,to,start=1){
  M = c(start,from,to)-1;  m = length(M);  E = matrix(0,m^2-m,3);  i = 0
  for(i1 in 1:m){
    for(i2 in 1:m){
      if(i1==i2){ next }
      i = i + 1
      E[i,] = c(M[i1]+1,M[i2]+1,abs(M[i1]%%n-M[i2]%%n)+abs(M[i1]%/%n-M[i2]%/%n))
    }
  }
  for(i in 1:length(to)){
    E[(E[,1]==start)&(E[,2]==to[i]),3] = 0;  E[(E[,1]==to[i])&(E[,2]==from[i]),3] = 0;  E[(E[,1]==from[i])&(E[,2]==start),3] = 0
  }
  E = E[E[,3]!=0,]
  return(E)
}

PlotPath = function(Map){
  n = Map$size;  from = Map$from - 1;  to = Map$to - 1;  start = Map$start-1;  path = Map$path-1
  plot(c(1,1,n,n,1),c(1,n,n,1,1),col="grey",type="l",lwd=50/n,xlab="x",ylab="y",main="Delivery Map")
  for(i in 1:n){
    lines(c(1,n),c(i,i),col="grey",lwd=50/n);  lines(c(i,i),c(1,n),col="grey",lwd=50/n)
  }
  if(length(path)>0){
    for(i in 1:nrow(path)){
      s = c(path[i,1]%%n,path[i,1]%/%n)+1;  e = c(path[i,2]%%n,path[i,2]%/%n)+1
      lines(rbind(s,c(s[1],e[2]),e),lwd=10/n,col=1+(i==1))
    }
  }
  points(from%%n+1,from%/%n+1,col="blue",cex=15/n,pch=16)
  text(from%%n+1.3,from%/%n+1.3,col="blue",cex=15/n,label=1:length(from))
  points(to%%n+1,to%/%n+1,col="red",cex=15/n,pch=16)
  text(to%%n+1.3,to%/%n+1.3,col="red",cex=15/n,label=1:length(from))
  points(start%%n+1,start%/%n+1,cex=15/n,pch=16)
  text(start%%n+1.3,start%/%n+1.3,cex=15/n,label=0)
}

Locations = function(n,k){
  start = sample(1:n^2,1)
  from = sample((1:n^2)[-(start)],k)
  to = sample((1:n^2)[-c(start,from)],k)
  Map = list(size=n,start=start,from=from,to=to,path=NULL)
  PlotPath(Map)
  return(Map)
}

